# network-reborn-test.cluster-ca986recviua.ap-east-1.rds.amazonaws.com
# a123.ca986recviua.ap-east-1.rds.amazonaws.com
rds_host = "network-reborn-test.cluster-ca986recviua.ap-east-1.rds.amazonaws.com"
username = "testing"
password = "biai1234"
db_name = "dashboard_data"